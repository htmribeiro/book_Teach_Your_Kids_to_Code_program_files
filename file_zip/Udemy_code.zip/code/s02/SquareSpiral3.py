# SquareSpiral3.py
import turtle
t = turtle.Pen()
t.speed(0)
t.pencolor("red")
for x in range(100):
    t.forward(2*x)
    t.left(91)
