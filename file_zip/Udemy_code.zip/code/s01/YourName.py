# YourName.py
name = input("What is your name?\n")
print("Hi, ", name, name, name, name, name)
