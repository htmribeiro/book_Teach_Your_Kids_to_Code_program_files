#Rosette6.py
import turtle
t = turtle.Pen()
t.speed(0)
for x in range(6):
    t.circle(100) 
    t.left(60)    
