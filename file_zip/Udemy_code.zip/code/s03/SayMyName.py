# SayMyName.py

# Ask the user for their name
name = input("What is your name? ")

# Print their name 100 times
for x in range(100):
    
    # Print their name followed by a space, not a new line
    print(name, end = " rules! ")
